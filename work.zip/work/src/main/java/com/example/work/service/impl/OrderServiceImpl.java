package com.example.work.service.impl;

import com.example.work.entity.Order;
import com.example.work.mapper.OrderMapper;
import com.example.work.service.OrderService;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.concurrent.TimeUnit;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderMapper orderMapper;

    @Autowired
    private StringRedisTemplate redisTemplate;

    @Autowired
    private RocketMQTemplate rocketMQTemplate;

    @Override
    @Transactional
    public String create(Order order) {

        String key = "lock:order:" + order.getUserId();

        Boolean ok = redisTemplate.opsForValue()
                .setIfAbsent(key, "1", 10, TimeUnit.SECONDS);

        if (Boolean.FALSE.equals(ok)) {
            return "请勿重复提交";
        }

        try {
            order.setStatus("NEW");
            orderMapper.insert(order);

            rocketMQTemplate.convertAndSend("order-topic", order);

            return "success";
        } finally {
            redisTemplate.delete(key);
        }
    }
}

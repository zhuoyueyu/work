package com.example.work.aspect;

import org.aspectj.lang.annotation.*;
import org.aspectj.lang.JoinPoint;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LogAspect {

    @Pointcut("execution(* com.example.work.service..*(..))")
    public void point(){}

    @Before("point()")
    public void before(JoinPoint jp){
        System.out.println("start: " + jp.getSignature().getName());
    }

    @After("point()")
    public void after(){
        System.out.println("end");
    }
}

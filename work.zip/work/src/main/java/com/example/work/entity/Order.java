package com.example.work.entity;

import lombok.Data;

@Data
public class Order {
    private Long id;
    private Long userId;
    private Double amount;
    private String status;
}

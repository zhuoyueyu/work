package com.example.work.service;

import com.example.work.entity.Order;

public interface OrderService {
    String create(Order order);
}

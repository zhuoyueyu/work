package com.example.work.controller;

import com.example.work.entity.Order;
import com.example.work.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/create")
    public String create(@RequestBody Order order) {
        return orderService.create(order);
    }
}
